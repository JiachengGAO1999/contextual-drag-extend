# Overleaf manuscript project

Upload this ZIP as a new project. All project files are at the archive root.

- Main document: main.tex
- Compiler: pdfLaTeX
- TeX Live version: 2024, to match the local manuscript build
- Bibliography: BibTeX with iclr2027_conference.bst

The latexmkrc requests pdfLaTeX. Confirm the compiler and TeX Live version in
the project settings after import. The local manuscript ends its Conclusion
on page 9. Compare that page after the first Overleaf compilation, since the
remote environment has not been executed during packaging.

This project contains the current manuscript and every local input, figure,
bibliography, and bundled style dependency. It does not need the experiment
repository or any parent-directory paths. main.tex is the upload name of
contextual_drag_continued_access.tex; its contents are unchanged.
The supplementary code artifact is a separate submission file.
